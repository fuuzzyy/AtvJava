import java.util.Scanner;

public class basico9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário que insira um número
        System.out.print("Digite um número: ");
        int numero = scanner.nextInt();

        // Verifica se o número está no intervalo de 100 a 200 (inclusive)
        if (numero >= 100 && numero <= 200) {
            System.out.println(numero + " está dentro do intervalo de 100 a 200.");
        } else {
            System.out.println(numero + " está fora do intervalo de 100 a 200.");
        }

        scanner.close();
    }
}

