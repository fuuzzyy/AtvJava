import java.util.Scanner;

public class condição4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário que insira uma palavra
        System.out.print("Digite uma palavra: ");
        String palavra = scanner.nextLine();

        // Verifica se a palavra tem mais de 5 caracteres
        if (palavra.length() > 5) {
            System.out.println("A palavra \"" + palavra + "\" tem mais de 5 caracteres.");
        } else {
            System.out.println("A palavra \"" + palavra + "\" tem 5 ou menos caracteres.");
        }

        scanner.close();
    }
}

