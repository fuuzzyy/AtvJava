import java.util.Scanner;

public class dec6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o valor da compra: ");
        double valorCompra = scanner.nextDouble();

        double valorMinimo = 100.0;

        if (valorCompra >= valorMinimo) {
            System.out.println("Parabéns! Você ganhou um brinde.");
        } else {
            System.out.println("Infelizmente, sua compra não atingiu o valor mínimo para o brinde.");
        }

        scanner.close();
    }
}


