import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class dt5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        System.out.print("Digite a data (dd/MM/yyyy): ");
        String dataStr = scanner.nextLine();
        LocalDate data = LocalDate.parse(dataStr, formatter);

        LocalDate inicio = LocalDate.of(2024, 1, 1);
        LocalDate fim = LocalDate.of(2024, 12, 31);

        if (!data.isBefore(inicio) && !data.isAfter(fim)) {
            System.out.println("A data está dentro do período especificado.");
        } else {
            System.out.println("A data está fora do período especificado.");
        }

        scanner.close();
    }
}
