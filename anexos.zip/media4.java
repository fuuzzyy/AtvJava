import java.util.Scanner;

public class media4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário que insira a nota
        System.out.print("Digite a nota do aluno: ");
        double nota = scanner.nextDouble();

        // Verifica se o aluno foi aprovado e se tirou nota máxima
        if (nota >= 6) {
            if (nota == 10) {
                System.out.println("O aluno foi aprovado com nota máxima!");
            } else {
                System.out.println("O aluno foi aprovado.");
            }
        } else {
            System.out.println("O aluno foi reprovado.");
        }

        scanner.close();
    }
}

