import java.util.Scanner;

public class media5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita as notas das duas disciplinas
        System.out.print("Digite a nota da primeira disciplina: ");
        double nota1 = scanner.nextDouble();

        System.out.print("Digite a nota da segunda disciplina: ");
        double nota2 = scanner.nextDouble();

        // Verifica se o aluno foi aprovado em ambas as disciplinas
        if (nota1 >= 6 && nota2 >= 6) {
            System.out.println("O aluno foi aprovado em ambas as disciplinas.");
        } else {
            System.out.println("O aluno não foi aprovado em ambas as disciplinas.");
        }

        scanner.close();
    }
}


