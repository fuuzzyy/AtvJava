import java.util.Scanner;

public class operação4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário que insira três números (lados do triângulo)
        System.out.print("Digite o primeiro lado do triângulo: ");
        double a = scanner.nextDouble();

        System.out.print("Digite o segundo lado do triângulo: ");
        double b = scanner.nextDouble();

        System.out.print("Digite o terceiro lado do triângulo: ");
        double c = scanner.nextDouble();

        // Verifica se os números podem formar um triângulo
        if (a + b > c && a + c > b && b + c > a) {
            System.out.println("Os lados podem formar um triângulo.");
        } else {
            System.out.println("Os lados NÃO podem formar um triângulo.");
        }

        scanner.close();
    }
}

