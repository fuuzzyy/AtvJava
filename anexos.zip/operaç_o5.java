import java.util.Scanner;

public class operação5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário para digitar um número
        System.out.print("Digite um número: ");
        int numero = scanner.nextInt();

        // Calcula a raiz quadrada do número
        double raiz = Math.sqrt(numero);

        // Verifica se a raiz quadrada é um número inteiro
        if (raiz == (int) raiz) {
            System.out.println(numero + " é um quadrado perfeito.");
        } else {
            System.out.println(numero + " não é um quadrado perfeito.");
        }

        scanner.close();
    }
}


