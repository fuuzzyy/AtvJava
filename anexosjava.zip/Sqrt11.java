public class Sqrt11 {
    public static void main(String[] args) {
                double numero = 0.04;
                double raizQuadrada = Math.sqrt(numero);

                System.out.println("A raiz quadrada de " + numero + " é: " + raizQuadrada);
            }
        }

