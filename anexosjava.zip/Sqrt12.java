public class Sqrt12 {
        public static void main(String[] args) {
            double numero = 121;
            double raizQuadrada = Math.sqrt(numero);

            System.out.println("A raiz quadrada de " + numero + " é: " + raizQuadrada);
        }
    }

