public class Sqrt13 {
        public static void main(String[] args) {
            double numero = 625;
            double raizQuadrada = Math.sqrt(numero);

            System.out.println("A raiz quadrada de " + numero + " é: " + raizQuadrada);
        }
    }

