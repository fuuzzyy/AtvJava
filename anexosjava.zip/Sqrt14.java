import java.text.DecimalFormat;

public class Sqrt14 {
        public static void main(String[] args) {
            double numero = 50;
            double raizQuadrada = Math.sqrt(numero);

            DecimalFormat df = new DecimalFormat("#.00");
            String resultadoFormatado = df.format(raizQuadrada);

            System.out.println("A raiz quadrada de " + numero + " é: " + resultadoFormatado);
        }
    }

