package Math;

public class Pow10 {
    public static void main(String[] args) {
        System.out.println(Math.pow((-2),3));
    }
}
