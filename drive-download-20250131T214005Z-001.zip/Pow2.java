package Math;

public class Pow2 {
    public static void main(String[] args) {
        System.out.println(Math.pow(5,2));
    }
}
