package Math;

public class Pow4 {
    public static void main(String[] args) {
        System.out.println(Math.pow(3,4));
    }
}
