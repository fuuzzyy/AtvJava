package Math;

public class Pow5 {
    public static void main(String[] args) {
        System.out.println(Math.pow(7,2));
    }
}
