package Math;

public class Pow8 {
    public static void main(String[] args) {
        System.out.println(Math.pow(1,100));
    }
}
