package Math;

public class Pow9 {
    public static void main(String[] args) {
        System.out.println(Math.pow(4, 0.5));
    }
}
