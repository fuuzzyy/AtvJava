package Math;

public class Sqrt1 {
    public static void main(String[] args) {

        System.out.println(Math.sqrt(16));
    }
}
