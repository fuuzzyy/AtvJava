package Math;

public class Sqrt10 {
    public static void main(String[] args) {
        System.out.println(Math.sqrt(400));
    }
}
