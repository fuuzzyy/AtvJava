package Math;

public class Sqrt2 {
    public static void main(String[] args) {

        System.out.println(Math.sqrt(81));
    }
}
