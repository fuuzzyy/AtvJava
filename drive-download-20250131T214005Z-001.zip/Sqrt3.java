package Math;

import java.text.DecimalFormat;

public class Sqrt3 {
    public static void main(String[] args) {

        double numero = 2;
        double raizQ = Math.sqrt(numero);

        DecimalFormat df = new DecimalFormat("#.##");
        String resultado = df.format(raizQ);

        System.out.println("A raiz quadrada de " + numero + " é: " + resultado);
    }
}
