package Math;

public class Sqrt5 {
    public static void main(String[] args) {
        System.out.println(Math.sqrt(144));
    }
}
