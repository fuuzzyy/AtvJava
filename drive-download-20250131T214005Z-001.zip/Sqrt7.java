package Math;

public class Sqrt7 {
    public static void main(String[] args) {
        System.out.println(Math.sqrt(0.25));
    }
}
