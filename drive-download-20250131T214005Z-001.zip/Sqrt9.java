package Math;

import java.text.DecimalFormat;

public class Sqrt9 {
    public static void main(String[] args) {

        double numero = 10;
        double RaizQ = Math.sqrt(numero);

        DecimalFormat df = new DecimalFormat("#.#");
        String resultado = df.format(RaizQ);

        System.out.println("A raiz de " + numero +  " é :"  + resultado );
    }
}

