package ExerciciosIF_ELSE;

import java.util.Scanner;

public class Basico4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int idade;

        System.out.println("Qual a sua idade? ");
        idade = sc.nextInt();

        if(idade > 16){
            System.out.println("Você tem a idade necessaria para votar!");

        }else{
            System.out.println("Você não tem a idade necessaria para votar!");
        }
    }
}
