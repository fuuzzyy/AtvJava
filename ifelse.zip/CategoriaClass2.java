package IF_ELSE_EXERCÍCIOS;

import java.util.Scanner;

public class CategoriaClass2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int num;

        System.out.print("Digite o número: ");
        num = sc.nextInt();

        if(num >=1 && num <= 10){
            System.out.println("O número pertence à faixa de classificação 'A'!");

        }else if(num >=11 && num <=20){
            System.out.println("O número pertence à faixa de classificação 'B'!");

        }else if(num >=21 && num <= 30){
            System.out.println("0 número pertence à faixa de classificação 'C'!");


        }
    }
}
