package IF_ELSE_EXERCÍCIOS;

import java.util.Scanner;

public class CategoriaClass3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int altura;

        System.out.print("Digite o número: ");
        altura = sc.nextInt();

        if(altura >=150 && altura <= 160){
            System.out.println("Você é considerada uma pessoa baixa!");

        }else if(altura >=160 && altura <=175){
            System.out.println("Você é considerada uma pessoa média!");

        }else if(altura >=175 && altura <= 200){
            System.out.println("Você é considerada uma pessoa alta!");


        }
    }
}
