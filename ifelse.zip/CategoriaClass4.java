import java.util.Scanner;

public class CategoriaClass4 {
    public static void main(String[] args) {
                Scanner scanner = new Scanner(System.in);

                System.out.print("Digite o valor da pressão alta: ");
                int pressaoCima = scanner.nextInt();

                System.out.print("Digite o valor da pressão baixa: ");
                int pressaoBaixo = scanner.nextInt();

                String risco;

                if (pressaoCima < 120 && pressaoBaixo < 80) {
                    risco = "Normal";
                } else if ((pressaoCima >= 120 && pressaoCima <= 139) || (pressaoBaixo >= 80 && pressaoBaixo <= 89)) {
                    risco = "Moderado";
                } else {
                    risco = "Alto";
                }

                System.out.println("Nível de risco: " + risco);

                scanner.close();
            }
        }



