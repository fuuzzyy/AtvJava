import java.util.Scanner;

public class CategoriaClass5 {
    public static void main(String[] args) {
                Scanner scanner = new Scanner(System.in);

                System.out.print("Digite a temperatura em graus Celsius: ");
                int temperatura = scanner.nextInt();

                String condicao;

                if (temperatura < 15) {
                    condicao = "Frio";
                } else if (temperatura >= 15 && temperatura <= 25) {
                    condicao = "Agradável";
                } else {
                    condicao = "Quente";
                }

                System.out.println("Está " + condicao);

                scanner.close();
            }
        }

