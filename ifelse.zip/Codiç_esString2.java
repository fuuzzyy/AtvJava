package ExerciciosIF_ELSE;

import java.util.Scanner;

public class CodiçõesString2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String senha = "1234";
        int s;

        System.out.println("Digite a senha: ");
        s = sc.nextInt();

        if(s == 1234){
            System.out.println("Acesso liberado!");
        }else{
            System.out.println("Acesso negado!");
        }
    }
}
