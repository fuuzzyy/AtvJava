package IF_ELSE_JAVA;

import java.util.Scanner;

public class CondiçõesString4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite uma palavra: ");
        String palavra = scanner.nextLine();
        if (palavra.length() > 5) {
            System.out.println("A palavra contém mais de 5 caracteres.");
        } else {
            System.out.println("A palavra NÃO contém mais de 5 caracteres.");
        }

    }

}