package IF_ELSE_EXERCÍCIOS;

import java.util.Scanner;

public class DatasHorários1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int hora;

        System.out.print("Que horas são: ");
        hora = scanner.nextInt();

        if(hora <=24){
            System.out.println("O horário é valido!");

        }else{
            System.out.println("Esse horário é invalido,tente novamente!");
        }
    }
}
