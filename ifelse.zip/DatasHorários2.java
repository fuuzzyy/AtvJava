package IF_ELSE_EXERCÍCIOS;

import java.util.Scanner;

public class DatasHorários2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int Mes;

        System.out.print("Em que Mês estamos: ");
        Mes = scanner.nextInt();

        if(Mes <= 12){
            System.out.println("Esse Mês é valido!");

        }else{
            System.out.println("Esse Mês não existe!");
        }
    }
}
