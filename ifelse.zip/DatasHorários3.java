package IF_ELSE_EXERCÍCIOS;

import java.util.Scanner;

import java.util.Scanner;

public class DatasHorários3 {

    // Método para verificar se o ano é bissexto
    public static boolean isAnoBissexto(int ano) {
        return (ano % 4 == 0 && (ano % 100 != 0 || ano % 400 == 0));
    }

    // Método para verificar se o dia é válido para o mês
    public static boolean diaValido(int mes, int dia, int ano) {
        int diasNoMes = 0;

        // Usa o switch case para determinar o número de dias por mês
        switch (mes) {
            case 1: // Janeiro
            case 3: // Março
            case 5: // Maio
            case 7: // Julho
            case 8: // Agosto
            case 10: // Outubro
            case 12: // Dezembro
                diasNoMes = 31;
                break;
            case 4: // Abril
            case 6: // Junho
            case 9: // Setembro
            case 11: // Novembro
                diasNoMes = 30;
                break;
            case 2: // Fevereiro
                if (isAnoBissexto(ano)) {
                    diasNoMes = 29;
                } else {
                    diasNoMes = 28;
                }
                break;
            default:
                // Mês inválido
                return false;
        }


        return dia >= 1 && dia <= diasNoMes;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        System.out.print("Digite o mês (1 a 12): ");
        int mes = scanner.nextInt();

        System.out.print("Digite o dia: ");
        int dia = scanner.nextInt();

        System.out.print("Digite o ano: ");
        int ano = scanner.nextInt();


        if (mes >= 1 && mes <= 12 && diaValido(mes, dia, ano)) {
            System.out.println("O dia " + dia + " é válido para o mês " + mes + " do ano " + ano + ".");
        } else {
            System.out.println("O dia " + dia + " não é válido para o mês " + mes + " do ano " + ano + ".");
        }



    }
}
