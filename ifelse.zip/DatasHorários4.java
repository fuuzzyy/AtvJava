import java.util.Scanner;

public class DatasHorários4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite a hora (0-23): ");
        int hora = scanner.nextInt();

        String periodo;

        if (hora >= 6 && hora < 12) {
            periodo = "Manhã";
        } else if (hora >= 12 && hora < 18) {
            periodo = "Tarde";
        } else {
            periodo = "Noite";
        }

        System.out.println("O horário informado corresponde ao período da " + periodo + ".");

        scanner.close();
    }
}



