package IF_ELSE_EXERCÍCIOS;

import java.util.Scanner;

public class DecisõesFinan1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int saldo = 5000;

        System.out.print("Digite o valor do saque: ");
        saldo = scanner.nextInt();

        if(saldo <= 5000){
            System.out.println("Saque realizado com sucesso!");

        }else{
            System.out.println("Saldo insuficiente,tente outro valor!");
        }
    }
}
