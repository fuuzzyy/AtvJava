package IF_ELSE_EXERCÍCIOS;

import java.util.Scanner;

public class DecisõesFinan2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o valor total da compra: R$ ");
        double valorCompra = scanner.nextDouble();


        double desconto = 0.0;


        if (valorCompra > 500) {
            desconto = valorCompra * 0.10;
        }


        double valorFinal = valorCompra - desconto;


        System.out.println("Desconto aplicado: R$ " + desconto);
        System.out.println("Valor final a pagar: R$ " + valorFinal);


    }

}
