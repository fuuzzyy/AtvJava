package IF_ELSE_EXERCÍCIOS;

import java.util.Scanner;

public class DecisõesFinan3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int imovel, salario;

        System.out.print("Digite seu Salário: ");
        salario = scanner.nextInt();

        if(salario >= 3000){
            System.out.println("Você pode financiar um imóvel!");

        }else{
            System.out.println("Seu salário não é o suficiente para financiar um imóvel");
        }
    }
}
