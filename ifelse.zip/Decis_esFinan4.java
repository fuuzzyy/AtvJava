import java.util.Scanner;

public class DecisõesFinan4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o valor do salário: ");
        double salario = scanner.nextDouble();

        System.out.print("Digite o valor da parcela: ");
        double parcela = scanner.nextDouble();

        if (parcela <= 0.1 * salario) {
            System.out.println("Compra aprovada! Você pode parcelar este produto.");
        } else {
            System.out.println("Compra negada! O valor da parcela excede 10% do seu salário.");
        }

        scanner.close();
    }
}


