package IF_ELSE_JAVA;

import java.util.Random;
import java.util.Scanner;

public class DesafiosJogos3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        int numeroSecreto = random.nextInt(100) + 1;
        int tentativa;
        boolean acertou = false;

        System.out.println("Bem-vindo ao Jogo de Adivinhação!");
        System.out.println("Tente adivinhar o número secreto entre 1 e 100.");

        while (!acertou) {
            System.out.print("Digite seu palpite: ");
            tentativa = scanner.nextInt();

            if (tentativa == numeroSecreto) {
                System.out.println("Parabéns! Você acertou o número secreto: " + numeroSecreto);
                acertou = true;
            } else if (tentativa < numeroSecreto) {
                System.out.println("O número secreto é maior. Tente novamente!");
            } else {
                System.out.println("O número secreto é menor. Tente novamente!");
            }
        }


    }
    }

