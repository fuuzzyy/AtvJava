import java.util.Scanner;
import java.util.Random;
public class DesafiosJogos5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Random random = new Random();

        // Sorteia um número entre 1 e 10
        int numeroSorteado = random.nextInt(10) + 1;

        // Solicita que o usuário insira um número
        System.out.print("Adivinhe o número entre 1 e 10: ");
        int numeroUsuario = scanner.nextInt();

        // Verifica se o usuário acertou o número
        if (numeroUsuario == numeroSorteado) {
            System.out.println("Parabéns! Você acertou o número.");
        } else {
            System.out.println("Que pena! O número sorteado foi: " + numeroSorteado);
        }


        scanner.close();
    }
}

