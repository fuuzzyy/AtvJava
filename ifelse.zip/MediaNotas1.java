package ExerciciosIF_ELSE;

import java.util.Scanner;

public class MediaNotas1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int Notas;


        System.out.println("Digite a primeira nota: ");
        Notas = sc.nextInt();

        System.out.println("Digite a segunda nota: ");
        Notas = sc.nextInt();

        if(Notas >= 7){
            System.out.println("Você está aprovado!");
        }else{
            System.out.println("Você não está aprovado!");
        }
    }
}
