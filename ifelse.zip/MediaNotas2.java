package IF_ELSE_JAVA;

import java.util.Scanner;

public class MediaNotas2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita a média do aluno
        System.out.print("Digite a média do aluno: ");
        double media = scanner.nextDouble();

        // Verifica a situação do aluno
        if (media >= 7.0) {
            System.out.println("Aluno Aprovado!");
        } else if (media >= 5.0 && media < 7.0) {
            System.out.println("Aluno em Recuperação.");
        } else {
            System.out.println("Aluno Reprovado.");
        }

        scanner.close();
    }
}

