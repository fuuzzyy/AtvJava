package ExerciciosIF_ELSE;

import java.util.Scanner;

public class MediaNotas5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double notaMinima = 6;
        double nota1,nota2;

        System.out.print("Digite a nota da primeira disciplina: ");
         nota1 = sc.nextDouble();

        System.out.print("Digite a nota da segunda disciplina: ");
         nota2 = sc.nextDouble();

        if (nota1 >= notaMinima && nota2 >= notaMinima) {
            System.out.println("O aluno foi aprovado em ambas as disciplinas!");
        } else {
            System.out.println("O aluno não foi aprovado em ambas as disciplinas.");

            // Verificando em quais disciplinas o aluno foi aprovado
            if (nota1 >= notaMinima) {
                System.out.println("O aluno foi aprovado na primeira disciplina.");
            } else {
                System.out.println("O aluno não foi aprovado na primeira disciplina.");
            }

            if (nota2 >= notaMinima) {
                System.out.println("O aluno foi aprovado na segunda disciplina.");
            } else {
                System.out.println("O aluno não foi aprovado na segunda disciplina.");
            }
        }
            sc.close();
    }
}

