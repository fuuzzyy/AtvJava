package IF_ELSE_JAVA;

import java.util.Scanner;

public class OperaçõesMat4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o primeiro número: ");
        int num1 = scanner.nextInt();
        System.out.print("Digite o segundo número: ");
        int num2 = scanner.nextInt();
        System.out.print("Digite o terceiro número: ");
        int num3 = scanner.nextInt();

        if (num1 + num2 > num3 && num1 + num3 > num2 && num2 + num3 > num1) {
            System.out.println("Os números podem formar um triângulo.");
        } else {
            System.out.println("Os números NÃO podem formar um triângulo.");
        }
    }
}
