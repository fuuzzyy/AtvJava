package IF_ELSE_JAVA;

import java.util.Scanner;

public class OperaçõesMat5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite um número para verificar se é um quadrado perfeito: ");
        int num4 = scanner.nextInt();
        boolean isQuadradoPerfeito = Math.pow((int) Math.sqrt(num4), 2) == num4;
        if (isQuadradoPerfeito) {
            System.out.println("O número é um quadrado perfeito.");
        } else {
            System.out.println("O número NÃO é um quadrado perfeito.");
        }

    }
}
