package IF_ELSE_JAVA;

import java.util.Scanner;

public class SituaçõesCotidianas1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite a placa do veículo (somente números): ");
        String placa = scanner.nextLine();


        char ultimoDigito = placa.charAt(placa.length() - 1);


        if (Character.isDigit(ultimoDigito)) {
            int numero = Character.getNumericValue(ultimoDigito);

            if (numero % 2 == 0) {
                System.out.println("A placa termina em número PAR. O veículo pode passar.");
            } else {
                System.out.println("A placa termina em número ÍMPAR. O veículo NÃO pode passar.");
            }
        } else {
            System.out.println("Entrada inválida! Certifique-se de digitar apenas números.");
        }


    }
}

