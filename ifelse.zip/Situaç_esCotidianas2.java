package IF_ELSE_JAVA;

import java.util.Scanner;

public class SituaçõesCotidianas2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int CODIGO_CORRETO = 1234;

        System.out.print("Digite o código de acesso: ");
        int codigoDigitado = scanner.nextInt();

        if (codigoDigitado == CODIGO_CORRETO) {
            System.out.println("Acesso permitido!");
        } else {
            System.out.println("Código incorreto! Acesso negado.");
        }


    }
    }

