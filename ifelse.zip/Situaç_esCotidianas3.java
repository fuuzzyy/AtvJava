package IF_ELSE_JAVA;

import java.util.Scanner;

public class SituaçõesCotidianas3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Entrada da temperatura em Celsius
        System.out.print("Digite a temperatura em Celsius: ");
        double celsius = scanner.nextDouble();

        // Escolha do usuário
        System.out.println("Escolha a conversão:");
        System.out.println("1 - Fahrenheit");
        System.out.println("2 - Kelvin");
        System.out.print("Opção: ");
        int opcao = scanner.nextInt();


        switch (opcao) {
            case 1:
                double fahrenheit = (celsius * 9 / 5) + 32;
                System.out.println("Temperatura em Fahrenheit: " + fahrenheit + "°F");
                break;
            case 2:
                double kelvin = celsius + 273.15;
                System.out.println("Temperatura em Kelvin: " + kelvin + "K");
                break;
            default:
                System.out.println("Opção inválida! Escolha 1 ou 2.");
        }


    }

}
