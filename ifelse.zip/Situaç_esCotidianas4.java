import java.util.Scanner;

public class SituaçõesCotidianas4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita a idade da pessoa
        System.out.print("Digite a sua idade: ");
        int idade = scanner.nextInt();

        // Solicita o peso da pessoa
        System.out.print("Digite o seu peso (em kg): ");
        double peso = scanner.nextDouble();

        // Verifica se a pessoa está apta para doar sangue
        if (idade >= 18 && idade <= 65 && peso >= 50) {
            System.out.println("Você está apto(a) para doar sangue!");
        } else {
            System.out.println("Você não está apto(a) para doar sangue.");

            // Exibe os motivos da inaptidão
            if (idade < 18) {
                System.out.println("Motivo: Idade mínima para doação é 18 anos.");
            } else if (idade > 65) {
                System.out.println("Motivo: Idade máxima para doação é 65 anos.");
            }
            if (peso < 50) {
                System.out.println("Motivo: Peso mínimo para doação é 50 kg.");
            }
        }

        scanner.close();
    }
}

