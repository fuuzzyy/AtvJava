import java.util.Scanner;

public class SituaçõesCotidianas5 {

    public static void main(String[] args) {
            // Defina o nome de usuário e senha esperados
            String usuarioCorreto = "aninhalinda";
            String senhaCorreta = "1234";

            // Crie um objeto Scanner para ler a entrada do usuário
            Scanner scanner = new Scanner(System.in);

            // Solicite ao usuário que insira o nome de usuário
            System.out.print("Digite o nome de usuário: ");
            String usuario = scanner.nextLine();

            // Solicite ao usuário que insira a senha
            System.out.print("Digite a senha: ");
            String senha = scanner.nextLine();

            // Verifique se o nome de usuário e a senha estão corretos
            if (usuario.equals(usuarioCorreto) && senha.equals(senhaCorreta)) {
                System.out.println("Autenticação bem-sucedida! Bem-vindo, " + usuario + ".");
            } else {
                System.out.println("Nome de usuário ou senha incorretos. Tente novamente.");
            }


            scanner.close();
        }
    }
