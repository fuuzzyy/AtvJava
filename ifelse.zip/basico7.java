import java.util.Scanner;

public class basico7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // Solicita ao usuário que insira um caractere
        System.out.print("Digite um caractere: ");
        char caractere = sc.next().charAt(0);

        // Verifica se o caractere é uma vogal
        if (caractere == 'a' || caractere == 'e' || caractere == 'i' || caractere == 'o' || caractere == 'u') {
            System.out.println(caractere + " é uma vogal.");
        } else {
            System.out.println(caractere + " não é uma vogal.");
        }

        sc.close();
    }
}

