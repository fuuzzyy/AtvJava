import java.util.Scanner;

public class basico8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário que insira um número
        System.out.print("Digite um número: ");
        int numero = scanner.nextInt();

        // Verifica se o número está no intervalo de 10 a 50 (inclusive)
        if (numero >= 10 && numero <= 50) {
            System.out.println(numero + " está dentro do intervalo de 10 a 50.");
        } else {
            System.out.println(numero + " está fora do intervalo de 10 a 50.");
        }

        scanner.close();
    }
}

